def get_by(list1,dict1):
    keys = list(dict1.keys())
    result = []
    for i in keys :
        for j in list1:
            if dict1[str(i)] == j:
                result.append(j)
    return result
print( get_by([47,64,69,37,76,83,95,97]
,{'yassine': 47, 'imane':69,'mohammed':76, 'abir':97 }))