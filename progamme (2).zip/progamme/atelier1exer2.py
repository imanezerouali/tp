n = int(input("veuillez saisir un nombre : ")) #demander a l 'utilisateur d'entree une valeur
b = 0
ord = 0
while n != 0 : #une boucle si n=0
    reste = n % 2
    p = 10 ** ord
    b = b+ reste * p
    ord = ord + 1
    n = n // 2
print(b) #affichage
