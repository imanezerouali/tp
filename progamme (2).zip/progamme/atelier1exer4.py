def fibonacci(n): #definir la fonction
       if(n<=1): #determiner les cas  exclus
          return n
       else:
          return (fibonacci(n-1)+fibonacci(n-2)) #definir la fonction avec recursivite
n = int(input("entrez le nombre de termes ; "))

print("suite  de fibonacci en utilisant la recursion :") #affichage
for i in range(n):
        print(fibonacci(i))