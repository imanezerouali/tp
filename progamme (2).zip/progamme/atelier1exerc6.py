# tri par insertion
# si la valeut est plus grande que la precedente on passe a la suivante
def sort_by_insertion(data):
    i =  0
    while( i < len(data) - 1):
        if data[i] > data[i + 1]:
            j = data[i + 1]
            data[i + 1] = data[i]
            data[i] = j
        i = i + 1
    return data

#tri par Bull
## I the most efficient
### That's by iterating the whole list and
# getting the minimum each time and append to a new list
def sort_by_bull(data, a):
    if data == []:
        return a
    num1 = min(data)
    a.append(num1)
    data.remove(num1)
    return sort_by_bull(data, list(a))


# par selection
# decroissant
#on coisit un element et on le compare avec le reste du tableau
def sort_by_selection(data):
    n = len(data)
    for i in range(0, n - 2):
        min = i
        for j in range(i + 1, n - 1):
            if data[j] < data[min]:
                min = j
        if min != i:
            temp = data[min]
            data[min] = data[i]
            data[i] = temp
    return data


# affichage Finale
print(sort_by_selection([8, 9, 9, 9, 9]))
print(sort_by_selection([2, 6, 7, 1, 2]))
print(sort_by_bull([0, 1, 7, 3, 4], []))