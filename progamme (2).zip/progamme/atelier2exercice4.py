def difference(set1, set2):
    a = set((""))
    for i in set1:
        for j in set2:
            if i == j: a.add(i)
    b = set1.copy()
    for i in set1:
        if i in a: b.remove(i)

    print("this is the difference => ", a,"his is the remainder of set1", b)

print(difference ({23, 42, 65, 57, 78, 83, 29}, {57, 83, 29, 67, 73, 43, 48}))