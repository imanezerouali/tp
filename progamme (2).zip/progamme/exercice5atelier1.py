# la Function qui renvoie les valeurs
def get_number(num):
    if len(num) > 1:
        # iterer dans la liste d'une maniere successive
        return get_number(num[0:len(num) - 1]) + 1
    return 1


# Printing the Result
print(get_number(str(input("put the number here "))))