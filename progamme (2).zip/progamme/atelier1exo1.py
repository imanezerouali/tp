while True :
    n=int (input ("veuillez saisir la valeur de n ")) #demande d'entrer la valeur de n
    if n > 0 :

        F =1 #initialiser a la valeur 1 car c'est l'element neutre de la multiplication
        s =0 #initialiser a la valeur 1 car c'est l'element neutre de l'addition
        for i in range(1,n+1):
            F = F*i
            s =s + F/i  #definir la relation qui permet d'avoir le resultat d'exerc

        print("la somme de la serie pour ",n," est de : " ,s)  #afficher le resultat