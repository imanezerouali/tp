def get_occurence(struct, i): #definir la fonction qui determine
    # le nombre d'existence d'un element
    ocr = 0 #initialiser le compteur a 0
    for k in struct: #la boucle pour encourir le tableau
        if k == i:
            ocr = ocr + 1
    return ocr

# affichage du resultat final

print(get_occurence([3, 7, 9, 0, 5], 1))